/*
 * Program Name: Assignment 8
 * Author: Jordan Johnson
 * IDE Used: Eclipse
 * Program description: Using a class created and defined in seperate files,
 * 						creates multiple Stores with various data that is assigned and output for the user
 */

/* preprocessor directives */
#include <iostream>
#include "Store.h"
using namespace std;

/* constants */
const int SIZE = 3;

/* function prototypes */
void plagiarismPledge();

/* main function */
int main ()
{
	/* declarations */
	Store myStores[SIZE] = { Store("McDonalds", "123 Main Street", "Tracy", 8735, 111860.50),
							 Store ("First Street Ale House", "238 1st Street", "Livermore", 001, 438219.25) };
	double totalRev = 0;

	/* welcome message */
	cout << "Welcome!"
		 << "\nThis program will output data about various restaurants."
		 << "\nProcessing... done!\n\n";

	/* adds info for the last store into the array */
	myStores[SIZE - 1].setName("Chick-Fil-A");
	myStores[SIZE - 1].setAddress("491 Capitol Expressway");
	myStores[SIZE - 1].setCity("San Jose");
	myStores[SIZE - 1].setStoreNum(2372);
	myStores[SIZE - 1].setAnnualRev(625921.75);

	/* outputs stores, then finds and outputs total revenue */
	for (int i = 0; i < SIZE; i++)
	{
		myStores[i].print();
		totalRev += myStores[i].getAnnualRev();
	}
	cout << "In addition, the total revenue for all of these stores is S" << totalRev << ".";

	/* ends program */
	plagiarismPledge();
	return(0);
}

/*
 * Function name: plagiarismPledge
 * Purpose: function to simply output the plagiarism pledge at the end of the program
 * Parameters: none
 * Returns: none
 * Return type: void
 */
void plagiarismPledge()
{
	cout << "\n\nI attest that this code is my original programming work,\nand that I received "
		 << "no help creating it. I attest that I did not\ncopy this code or any portion of this"
		 << "code from any source.";
};
