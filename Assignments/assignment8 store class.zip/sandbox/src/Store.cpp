/*
 * Store.cpp
 * sandbox
 *
 * Jordan Johnson
 */

/* preprocessor directives */
#include "Store.h"
#include <iomanip>
using namespace std;

Store :: Store()
{
	name = "";
	address = "";
	city = "";
	storeNum = 0;
	annualRev = 0;
}

Store :: Store(string n, string a, string c, int sN, double aR)
{
	name = n;
	address = a;
	city = c;
	storeNum = sN;
	annualRev = aR;
}

Store :: Store(string n, int sN)
{
	name = n;
	address = "";
	city = "";
	storeNum = sN;
	annualRev = 0;
}

void Store :: print()
{
	cout << "\t> Name: " << name << endl
		 << "\t> Address: " << address << endl
		 << "\t> City: " << city << endl
		 << "\t> Store Number: #" << storeNum << endl
		 << "\t> Annual Revenue: $" << setprecision(2) << fixed <<annualRev << endl
		 << endl;
}
