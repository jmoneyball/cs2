/*
 * Store.h
 * sandbox
 *
 * Jordan Johnson
 */

/* preprocessor directives */
#ifndef STORE_H
#define STORE_H
#include <iostream>
using namespace std;

/*
 * _______________________
 * STORE
 * _______________________
 * - name : string
 * - address : string
 * - city : string
 * - storeNumber : int
 * - annualRevenue : double
 * _______________________
 * + Store()
 * + Store(n: string, a: string, c: string, sN: int, aR: double)
 * + Store(n: string, sN: int)
 * + setName(n: string): void
 * + setAddress(a: string): void
 * + setCity(c: string): void
 * + setStoreNum(sN: int): void
 * + setAnnualRev(aR: double):void
 * + getName(): string
 * + getAddress(): string
 * + getCity(): string
 * + getStoreNum(): int
 * + getAnnualRev(): double
 * + print(): void
 * _______________________
 */

class Store
{
	private:
		string name, address, city;
		int storeNum;
		float annualRev;
	public:
		Store();
		Store(string, string, string, int, double);
		Store(string, int);
		void setName(string n)
		 	{ name = n; }
		void setAddress(string a)
			{ address = a; }
		void setCity(string c)
			{ city = c; }
		void setStoreNum(int sN)
			{ storeNum = sN; }
		void setAnnualRev(double aR)
			{ annualRev = aR; }
		string getName()
			{ return name; }
		string getAddress()
			{ return address; }
		string getCity()
			{ return city; }
		int getStoreNum()
			{ return storeNum; }
		double getAnnualRev()
			{ return annualRev; }
		void print();
};

#endif /* STORE_H */;
