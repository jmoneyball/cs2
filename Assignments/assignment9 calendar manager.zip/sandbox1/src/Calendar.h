/* Calendar class header */

/*
 _______________________
 	 	Calendar
 _______________________
 - day: int
 - month: int
 - year: int
 - daysInMonth: vector <int>
 - daysInYear: int
 _______________________
 + Calendar()
 + Calendar(m: int, d: int, y: int)
 + setDay(d: int): void
 + setMonth(m: int): void
 + setYear(y: int): void
 + getDay(): int
 + getMonth(): int
 + getYear(): int
 + print(): void
 + isLeapYear(): bool
 + daysThisMonth(): int
 + daysPassed(): int
 + daysRemaining(): int
 _______________________
*/

/* preprocessor directives */
#ifndef CALENDAR_H
#define CALENDAR_H
#include <iostream>
#include <cstdlib>
#include <vector>
using namespace std;

class Calendar
{
	private:
		int day;
		int month;
		int year;
		vector <int> daysInMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
		int daysInYear = 365;
	public:
		Calendar()
			{ month = 1; day = 1; year = 1; }
		Calendar(int m, int d, int y);
		void setDay(int d)
			{ day = d; }
		void setMonth(int m)
			{ month = m; }
		void setYear(int y)
			{ year = y; }
		int getDay()
			{ return day; }
		int getMonth()
			{ return month; }
		int getYear()
			{ return year; }
		void print()
		{ cout << "The given date is " << month << "/" << day << "/" << year << endl; }
		bool isLeapYear();
		int daysThisMonth()
			{ return (daysInMonth[month - 1]); }
		int daysPassed();
		int daysRemaining();
};

#endif /* CALENDAR_H */

