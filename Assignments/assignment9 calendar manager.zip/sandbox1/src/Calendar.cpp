/* Calendar class implementation */

/* preprocessor directives */
#include "Calendar.h"

/* constructor */
Calendar :: Calendar(int m, int d, int y)
{
	day = d;
	month = m;
	year = y;

	/* data validation */
	if (day <= 0 or month <= 0 or year <= 0)
	{
		cout << "Data error; one or more values is less than zero.\n";
		exit(EXIT_FAILURE);
	}

	/* tests if given year is a leap year to accomodate for extra day */
	if (year % 4 == 0)
	{
		if (year % 100 == 0)
		{
			if (year % 400 == 0)
			{
				daysInMonth[true]++; /* adds an extra day if leap year */
				daysInYear++;
			}
		}
		else
		{
			daysInMonth[true]++; /* adds an extra day if leap year */
			daysInYear++;
		}
	}
}

//isLeapYear(): determines if a given year is a leap year
//Arguments: none | Returns: tf (bool)
bool Calendar :: isLeapYear()
{
	bool tf = false;

	//runs a series of tests to determine if given year is a leap year
	if (year % 4 == 0)
		if (year % 100 == 0)
		{
			if (year % 400 == 0)
			{
				tf = true;
				return tf;
			}
			else
				return tf;
		}
		else
		{
			tf = true;
			return tf;
		}
	else
		return tf;
}

//daysPassed(): determines that amount of days so far in the year
//Arguments: none | Returns: daysSoFar (int)
int Calendar :: daysPassed()
{
	//counts total days that have occurred in the year
	int daysSoFar = day;
	for (int i = 0; i < month - 1; i++)
		daysSoFar += daysInMonth[i];

	return (daysSoFar);
}

//daysRemaining(): determines that amount of days remaining in the year
//Arguments: none | Returns: daysSoFar (int)
int Calendar :: daysRemaining()
{
	//counts total days that have occurred in the year
	int daysSoFar = day;
	for (int i = 0; i < month - 1; i++)
		daysSoFar += daysInMonth[i];

	return (daysInYear - daysSoFar);
}
