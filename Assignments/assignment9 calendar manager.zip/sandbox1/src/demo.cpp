/*
 Program Name: assignment9
 Author: Jordan Johnson
 IDE Used: Eclipse
 Program description: outputs data about any input calendar day
*/

/* preprocessor directives */
#include "Calendar.h"

/* function prototypes */
void printClassData(Calendar);
void plagiarismPledge();

/* main function */
int main ()
{
	//various Calendar dates being declared and output to console
	Calendar date1(2, 15, 2000);
	printClassData(date1);
	Calendar date2(10, 16, 2020);
	printClassData(date2);
	Calendar date3(2, 26, 2001);
	printClassData(date3);
	Calendar date4(12, 21, 1970);
	printClassData(date4);
	Calendar date5(8, 17, 1972);
	printClassData(date5);
	Calendar date6(9, 15, 1992);
	printClassData(date6);

	/* ends program */
	plagiarismPledge();
	return(0);
}

//printClassData(): uses class methods to print data about given class
//Arguments: none | Returns: void
void printClassData(Calendar c)
{
	//prints date
	c.print();

	//prints data about the given date
	if (c.isLeapYear() == true)
		cout << "\t> This year IS a leap year.\n";
	else cout << "\t> This year IS NOT a leap year\n";
	cout << "\t> " << c.daysThisMonth() << " days this month.\n"
		 << "\t> " << c.daysPassed() << " days passed so far this year.\n"
		 << "\t> " << c.daysRemaining() << " days remaining in the year.\n\n";
}

//plagiarismPledge(): function to simply output the plagiarism pledge at the end of the program
//Arguments: none | Returns: void
void plagiarismPledge()
{
	cout << "\n\nI attest that this code is my original programming work,\nand that I received "
		 << "no help creating it. I attest that I did not\ncopy this code or any portion of this"
		 << "code from any source.";
};
