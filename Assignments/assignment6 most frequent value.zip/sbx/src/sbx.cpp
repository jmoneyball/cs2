//*****************
//Program Name: assignment6
//Author: Jordan Johnson
//IDE Used: Eclipse
//Program description: finds the most frequent value of an array
//*****************

#include <iostream>
using namespace std;

//constant
const int SIZE = 10;

//prototype
int findMostFrequent(int *);

int main()
{
	//declares and outputs array of 10 numbers
	int myArray[SIZE] = {1, 2, 2, 3, 3, 3, 4, 5, 6, 7};

	cout << "Array numbers: ";
	for (int i = 0; i < SIZE; i++)
		cout << myArray[i] << " ";

	//attempts to find and output the most frequent number
	int mostFrequent = findMostFrequent(myArray);
		if (mostFrequent == false) //outputs if a frequent value does not occur
			cout << "\n\t--> There is no most frequent value";
		else //outputs if a frequent value occurs
			cout << "\n\t--> One of the most frequently occurring values (mode) is " << myArray[mostFrequent];

	//plagiarism pledge
	cout << "\n\nI attest that this code is my original programming work, and that I received"
		 <<	"\nno help creating it. I attest that I did not copy this code or any portion of this"
		 <<	"\ncode from any source.";

	return(0);
};

//*****************
//Function name: findMostFrequent
//Purpose: Pulls the most frequently occurring number from an array
//Parameters: integer array
//Returns: the integer index of the most frequently occurring value
//Return type: int
//*****************
int findMostFrequent(int *array)
{
	//creates a pointer for a dynamically allocated array
	int *frequency = new int[SIZE](); //initializes dynamic array to zero
	int mode = 0, modeIndex = 0;

	//counts the number of times each element appears in the dynamic frequency array
	for (int j = 0; j <= SIZE; j++)
	{
		for (int k = 0; k < SIZE; k++)
			if (*(array + k) == *(array + j))
				(*(frequency + j))++;
	};

	//finds the mode, then finds the index of the mode
	for (int l = 0; l < SIZE; l++)
	{
		if (*(frequency + l) > mode)
			mode = *(frequency + l);
		if (*(frequency + l) == mode)
			modeIndex = l;
	};

	delete [] frequency;
	if (mode == 1)
		return (false); //returns a false if no mode exists (if no number repeats more than once)
	else
		return (modeIndex); //returns the index of the mode if one exists
}
