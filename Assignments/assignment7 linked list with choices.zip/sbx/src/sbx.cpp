/*
 * Program Name: Assignment 7
 * Author: Jordan Johnson
 * IDE Used: Eclipse
 * Program description: creates a linked list of restaurant reviews with comments
 * that are input by the user.
 */

#include <iostream>
using namespace std;

/* structure declaration */
struct Node
{
	float rating;
	string comment;
	Node *next;
};

/* function prototypes */
int getMethodChoice();
Node* addToHead();
Node* addToTail();
void outputLinkedList(Node *);
void plagiarismPledge();

/* main function */
int main ()
{
	/* declarations */
	int methodChoice = getMethodChoice();
	Node *userReviews = nullptr;

	/* creates a linked list dependent on methodChoice */
	switch (methodChoice)
	{
		case 1:
			userReviews = addToHead();
			break;

		case 2:
			userReviews = addToTail();
			break;
	}

	/* sends list to a function to be output */
	outputLinkedList(userReviews);

	/* ends program */
	plagiarismPledge();
	return(0);
}

/*
 * Function name: getMethodChoice
 * Purpose: gets the users choice for which method they would like to create their linked list.
 * 			choice is returned to main to be assigned and used in the switch statement.
 * Parameters: none
 * Returns: mc
 * Return type: int
 */
int getMethodChoice()
{
	/* int indicating choice option picked by user */
	int mc;

	/* outputs prompt and gets user input */
	cout << "Which linked list method should we use?\n"
		 << "\t[1] New nodes are added at the head of the linked list\n"
		 << "\t[2] New nodes are added at the tail of the linked list\n"
		 << "\t--> ";
	cin  >> mc;
	/* input validation for int mc */
	while (mc != 1 && mc != 2)
	{
		cout << "\tERROR... please enter 1 or 2 only\n"
			 << "\t--> ";
		cin  >> mc;
	};

	/* returns user input to get assigned in main */
	return (mc);
};

/*
 * Function name: addToHead
 * Purpose: adds user input to the top of the linked list
 * Parameters: none
 * Returns: uRptr, a pointer to a Node
 * Return type: Node *
 */
Node* addToHead()
{
	/* pointer declaration */
	Node *uRptr = new Node;
	/* variable declarations */
	float ratings;
	string comments;
	int count = 0;
	/* do/while loop declarations */
	char userChoice;
	bool repeatLoop;

	do
	{
		/* increments the counter variable */
		count++;
		/* reinitializes the newReview temp pointer */
		Node *newReview = new Node;

		/* gets rating input from user */
		cout << "\nEnter review rating 0 - 5: ";
		cin  >> ratings;
		/* input validation for float ratings */
		while (ratings < 0 || ratings > 5)
		{
			cout << "ERROR... please enter a value 0 - 5 only: ";
			cin  >> ratings;
		};
		/* gets comment input from user */
		cout << "Enter review comments: ";
		cin.ignore();
		getline(cin, comments);

		if (count == 1)
		{
			uRptr = newReview;
			newReview -> next = nullptr;
			newReview -> rating = ratings;
			newReview -> comment = comments;
		}
		else
		{
			newReview -> next = uRptr;
			newReview -> rating = ratings;
			newReview -> comment = comments;
			uRptr = newReview;
		}

		/* gives user the option to enter another review into the linked list*/
		cout << "Enter another review? (y/n): ";
		cin  >> userChoice;
		userChoice = tolower(userChoice);
		/* input validation for char userChoice */
		while (userChoice != 'y' && userChoice != 'n')
		{
			cout << "ERROR... please enter y or n only: ";
			cin  >> userChoice;
			userChoice = tolower(userChoice);
		};

		/* ends loops if user chooses to not enter another review */
		if (userChoice == 'y') repeatLoop = true;
		else repeatLoop = false;
	} while (repeatLoop);

	return(uRptr);
};

/*
 * Function name: addToTail
 * Purpose: adds user input to the bottom of the linked list
 * Parameters: none
 * Returns: uRptr, a pointer to a Node
 * Return type: Node *
 */
Node* addToTail()
{
	/* pointer declarations */
	Node *uRptr = new Node;
	Node *last = new Node;
	Node *current = new Node;
	/* variable declarations */
	float ratings;
	string comments;
	int count = 0;
	/* do/while loop declarations */
	char userChoice;
	bool repeatLoop;

	do
	{
		/* increments the counter variable */
		count++;
		/* reinitializes the newReview temp pointer */
		Node *newReview = new Node;
		/* reassigns new uRptr to current pointer */
		current = uRptr;

		/* gets rating input from user */
		cout << "\nEnter review rating 0 - 5: ";
		cin  >> ratings;
		/* input validation for float ratings */
		while (ratings < 0 || ratings > 5)
		{
			cout << "ERROR... please enter a value 0 - 5 only: ";
			cin  >> ratings;
		};
		/* gets comment input from user */
		cout << "Enter review comments: ";
		cin.ignore();
		getline(cin, comments);

		if (count == 1)
		{
			newReview -> rating = ratings;
			newReview -> comment = comments;
			newReview -> next = nullptr;
			uRptr = newReview;
			last = newReview;
		}
		else
		{
			while (current != nullptr)
			{
				last = current;
				current = current -> next;
			}
			newReview -> rating = ratings;
			newReview -> comment = comments;
			newReview -> next = nullptr;
			last -> next = newReview;
		}

		/* gives user the option to enter another review into the linked list*/
		cout << "Enter another review? (y/n): ";
		cin  >> userChoice;
		userChoice = tolower(userChoice);
		/* input validation for char userChoice */
		while (userChoice != 'y' && userChoice != 'n')
		{
			cout << "ERROR... please enter y or n only: ";
			cin  >> userChoice;
			userChoice = tolower(userChoice);
		};

		/* ends loops if user chooses to not enter another review */
		if (userChoice == 'y') repeatLoop = true;
		else repeatLoop = false;
	} while (repeatLoop);

	return(uRptr);
};

/*
 * Function name: outputLinkedList
 * Purpose: outputs the linked list created by the user
 * Parameters: Node * (pointer to a Node, which is defined by struct up top)
 * Returns: none
 * Return type: void
 */
void outputLinkedList(Node *uRptr)
{
	/* declarations */
	int reviewCounter = 0;
	Node *current = uRptr;

	/* outputs everything in uRptr by continuously setting it current = nRptr,
	   then outputting its contents until current == nullptr, which is the
	   last element of nRptr
	*/
	cout << "\nOutputting all reviews:\n";
	while (current != nullptr)
	{
		reviewCounter++;
		cout << "\t> Review #" << reviewCounter << ": " << current -> rating
			 << " -- " << current -> comment << endl;
		current = current -> next;
	};
};

/*
 * Function name: plagiarismPledge
 * Purpose: function to simply output the plagiarism pledge at the end of the program
 * Parameters: none
 * Returns: none
 * Return type: void
 */
void plagiarismPledge()
{
	cout << "\n\nI attest that this code is my original programming work,\nand that I received "
		 << "no help creating it. I attest that I did not\ncopy this code or any portion of this"
		 << "code from any source.";
};
